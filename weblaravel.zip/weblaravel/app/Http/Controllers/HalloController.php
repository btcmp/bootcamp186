<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HalloController extends Controller
{
    
    public function index(){
        echo "hallo controller";
    }
    
    public function home(){
        echo "hallo home controller";
    }
    
}
