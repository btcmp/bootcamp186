<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VariantController extends Controller
{
    public function index(){
        $variants = DB::table('Variant')->get();
        $categories = DB::table('category')->get();
        
        $data = array(
            'variants' => $variants,
            'categories' => $categories
        );
        
        return view('variant', $data);
    }
    
    public function save(Request $request){
        
        //query builder
        $request->session()->flash('status', 'Data saved successful!');
        
        $data = array(
            'name' => $request->post('name'),
            'category_id' =>  $request->post('category_id')
        );
        $status = DB::table('Variant')->insert($data);
        return redirect('variant');
    }
    
    public function delete($id = null, Request $request){
        $request->session()->flash('status', 'Data Deleted successful!');
        DB::table('Variant')->where('id', $id)->delete();
        return redirect('variant');
    }
    
    public function getById($id = null, Request $request){
        $data = DB::table('Variant')
        ->join('category', 'category.id', '=', 'Variant.category_id')
        ->where('Variant.id', $id)->get();
        return json_encode($data->first());
    }
    
    public function update(Request $request){
         /* echo "<pre>";
         var_dump($request->post());
         echo "</pre>";
 */     $request->session()->flash('status', 'Data Updated successful!');
        $data = array(
            'name' => $request->post('variant_name_update'),
            'category_id' => $request->post('category_id_update')
        );
        
        DB::table('Variant')->where('id', $request->post('variant_id_update'))->update($data);
        return redirect('variant');;
    }
    
    public function getvariantbycategory($id = null){
        $variants = DB::table('Variant')
            ->select('Variant.id as variant_id', 'Variant.name as variant_name')
            ->join('category', 'category.id', '=', 'Variant.category_id')
            ->where('category.id', $id)
            ->get();
        
        return json_encode($variants);
    }
}
