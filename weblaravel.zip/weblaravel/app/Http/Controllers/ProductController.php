<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function index(){
        $products = DB::table('Products')->get();
        $categories = DB::table('category')->get();
        
        $data = array(
            'products' => $products,
            'categories' => $categories
        );
        
        return view('product', $data);
    }
    
    public function save(Request $request){   
        //query builder
        
        $validatedData = $request->validate([
            'name' => 'required|unique:posts|max:50',
            'price' => 'required',
        ]);
        
        if(!$validatedData){
            return redirect('product');
        }
        
        
        $request->session()->flash('status', 'Data saved successful!');
        
        $data = array(
            'name' => $request->post('name'),
            'price' => $request->post('price'),
            'stock' => $request->post('stock'),
            'category_id' =>  $request->post('category_id'),
            'variant_id' => $request->post('variant_id')
        );
        $status = DB::table('Products')->insert($data);
        return redirect('product');
    }
    
    public function delete($id = null, Request $request){
        $request->session()->flash('status', 'Data Deleted successful!');
        DB::table('Products')->where('id', $id)->delete();
        return redirect('product');
    }
    
    public function getById($id = null, Request $request){
        $data = DB::table('Products')
        ->join('category', 'category.id', '=', 'Products.category_id')
        ->where('Products.id', $id)->get();
        return json_encode($data->first());
    }
    
    public function update(Request $request){
        /*  echo "<pre>";
         var_dump($request->post());
         echo "</pre>"; */
        $request->session()->flash('status', 'Data Updated successful!');
        $data = array(
            'name' => $request->post('name_update'),
            'price' => $request->post('price_update'),
            'stock' => $request->post('stock_update'),
            'category_id' => $request->post('category_id_update')
        );
        
        DB::table('Products')->where('id', $request->post('id_update'))->update($data);
        return redirect('product');;
    }
    
    public function search($word= null, Request $request){
        $data = DB::table('Products')
            ->where('name', 'like', "%$word%")
            ->limit(1)
            ->get();
        
        return json_encode($data);
    }
}
