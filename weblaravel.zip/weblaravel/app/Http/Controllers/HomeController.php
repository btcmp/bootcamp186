<?php

namespace App\Http\Controllers;

class HomeController extends Controller{
    
    public function index(){
       // echo "home page";
       
        $data = array(
            'name' => 'arrizaqu',
            'address' => 'seputih banyak',
            'salary' => array(5000, 4000, 10000)
        );
        
        return view('home', $data); //find file home.blade.php
    }
    
}