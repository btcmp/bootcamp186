<?php

namespace App\Http\Controllers;

use App\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ApiProductController extends Controller
{
    //search
    public function search(Request $req){
        $data = DB::table('Products')
        ->where('name', 'like', '%'.$req->get('name').'%')
        ->get();
        
        return json_encode($data);
    }
    
    //save
    public function save(Request $request){
            //query builder
            $data = array(
                'name' => $request->post('name'),
                'price' => $request->post('price'),
                'stock' => $request->post('stock'),
                'category_id' => 0
            );
           // $status = DB::table('Products')->insert($data);
            
            //eloquen
//             $product = new Products();
//             $product->name = $request->post('name');
//             $product->price = $request->post('price');
//             $product->stock = $request->post('stock');
//             $product->category_id = 0;
//             $product->save(); 
            return "OK";
    }
    
    //update
    public function update(Request $req){
        $data = array(
            'name' => $req->post('name'),
            'price' => $req->post('price')
        );
        
        DB::table('Products')->where('id', $req->post('id'))->update($data);
        
        return "OK";
    }
    
    //delete
    public function delete($id = null){
        DB::table('Products')->where('id', $id)->delete();
        return "OK";
    }
    
    //get
    public function get(){
        $data = DB::table('Products')->get();
        return json_encode($data);
    }
    
    public function getById($id = 0){
        $data = DB::table('Products')->where('id', $id)->get();
        return json_encode($data->first());
    }
        
    
}
