<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class categoryController extends Controller
{
    public function index(){
        $categories = DB::table('category')->get();
        
        $data = array(
            'categories' => $categories
        );
        
        return view('category', $data);
    }
    
    public function save(Request $request){
        //query builder
        $request->session()->flash('status', 'Data saved successful!');
        
        $data = array(
            'category_name' => $request->post('category_name')
        );
        
        $status = DB::table('category')->insert($data);
        return redirect('category');
    }
    
    public function delete($id = null, Request $request){
        $request->session()->flash('status', 'Data Deleted successful!');
        DB::table('category')->where('id', $id)->delete();
        return redirect('category');
    }
    
    public function getById($id = null, Request $request){
        $data = DB::table('category')->where('id', $id)->get();
        return json_encode($data->first());
    }
    
    public function update(Request $request){
        /*  echo "<pre>";
         var_dump($request->post());
         echo "</pre>"; */
        $request->session()->flash('status', 'Data Updated successful!');
        $data = array(
            'category_name' => $request->post('category_name_update')
        );
        
        DB::table('category')->where('id', $request->post('category_id_update'))->update($data);
        return redirect('category');
    }
}
