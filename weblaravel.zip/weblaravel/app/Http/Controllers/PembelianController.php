<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PembelianController extends Controller
{
    public function index(){
        $result = DB::select(DB::raw("select nextval('seq_pembelian')"));
        $data = array(
            'no_faktur' => 'NO_FAKTUR_' . $result[0]->nextval 
        );
        
        return view('pembelian', $data);
    }
}
