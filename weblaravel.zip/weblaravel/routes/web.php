<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Products;

//type: TEXT/HTML
Route::get('/', function () {
    return view('welcome');
});

//homecontroller
Route::get("/home", 'HomeController@index');

Route::get("/hello", function(){
    return 'hello world php laravel framework';
});

//HelloController
Route::get('/hello2', 'HalloController@index');
Route::get('/hello3', 'HalloController@home');

//mydesign
Route::get('/design', function(){
    return view('design');
});

//REST API
//TYPE : JSON
//API => Application Programming interface
Route::get('/api/hello', function(){
    return 'hello world';    
});

//API product controller
Route::get('api/product/search', 'ApiProductController@search');
Route::post('api/product/save', 'ApiProductController@save');
Route::get("/api/product/get", 'ApiProductController@get');
Route::get('/api/product/get/{id?}', 'ApiProductController@getById' );
Route::put('api/product/update', 'ApiProductController@update');
Route::get('api/product/delete/{id?}', 'ApiProductController@delete');

// web product controller
Route::get('/product', 'ProductController@index');
Route::get('/product/get/{id?}', 'ProductController@getById');
Route::post('/product/save', 'ProductController@save');
Route::get('/product/search/{word?}', 'ProductController@search');
Route::post('/product/update', 'ProductController@update');
Route::get('/product/delete/{id?}', 'ProductController@delete');

// web category controller
Route::get('/category', 'CategoryController@index');
Route::get('/category/get/{id?}', 'CategoryController@getById');
Route::post('/category/save', 'CategoryController@save');
Route::post('/category/update', 'CategoryController@update');
Route::get('/category/delete/{id?}', 'CategoryController@delete');

// web variant controller
Route::get('/variant', 'VariantController@index');
Route::get('/variant/get/{id?}', 'VariantController@getById');
Route::post('/variant/save', 'VariantController@save');
Route::post('/variant/update', 'VariantController@update');
Route::get('/variant/delete/{id?}', 'VariantController@delete');
Route::get('/variant/getvariantbycategory/{id?}','VariantController@getvariantbycategory');

//web pembelian controller
Route::get('/pembelian', 'PembelianController@index');

Route::get('/template', function(){
    return view('template');    
});
//MVC
/*
 * Model => abstraksi data / database table
 * View => responsbility handle UI
 * Controller => handle request / response HTTP / Route
 * */
