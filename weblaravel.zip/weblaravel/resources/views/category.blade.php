@extends('layouts.mylayout')
@section('loadcss')
	@parent
	<link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
@endsection
@section('master-active', 'active')
@section('category-active', 'active')
@section('title', 'category')

@section('content')
@if (Session::has('status'))
       <div class="alert alert-success" >{!! session('status') !!}</div>
@endif

<div class="box box-info">
	<div class="box-header">
		<i class="fa fa-envelope"></i>

		<h3 class="box-title">Category Entry</h3>
		<!-- tools box -->
		<div class="pull-right box-tools">
			<button type="button" class="btn btn-info btn-sm"
				data-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
		<!-- /. tools -->
	</div>
	<div class="box-body">
		<form action="{{ asset('/category/save') }}" method="post">
			{{ csrf_field() }}
			<div class="form-group">
				<input type=text class="form-control" name="category_name"
					placeholder="Product Name">
			</div>
			<div class="box-footer clearfix">
				<input type="submit" name="submit" value="save" class="pull-right btn btn-primary" />
        	</div>
		</form>
	</div>
	
</div>
<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Master Category</h3>
		<div class="box-tools pull-right">
			<button type="button" class="btn btn-box-tool" data-widget="collapse">
				<i class="fa fa-minus"></i>
			</button>
			<button type="button" class="btn btn-box-tool" data-widget="remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
	</div>
	<!-- /.box-header -->
	<div class="box-body">
		<div class="table-responsive">
			<table id=table-category class="table table-bordered table-hover" style="width: 100%">
				<thead>
					<tr>
						<th>name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody> 
					@foreach ($categories as $category)
					<tr>
						<td>{{ $category->category_name }}</td>
						<td>
							<a href='#' onclick="confirmDelete('{{ $category->id }}')" class='btn btn-danger btn-sm'>Delete</a> 
							<a href='#' data-id = "{{ $category->id }}" class='update-category btn btn-warning btn-sm'>Update</a> 
							<a href='#' class='btn btn-info btn-sm'>View</a> 
						</td>
					</tr>
					@endforeach		
				</tbody>
			</table>
		</div>
		<!-- /.table-responsive -->
	</div>
	<!-- /.box-body -->
	<div class="box-footer clearfix">
		<a href="javascript:void(0)"
			class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a> <a
			href="javascript:void(0)"
			class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
	</div>
	<!-- /.box-footer -->
</div>
@endsection
<div id="update-modal" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{ asset('/category/update') }}" method="post">
			{{ csrf_field() }}
			<input type="hidden" name="category_id_update" />
			<div class="form-group">
				<input type=text class="form-control" name="category_name_update"
					placeholder="Category- Name">
			</div>
			
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-primary" value="Save change" />
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
@section('loadjs')
	@parent
	<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/demo.js"></script>
<script>
//javascript

function confirmDelete(id){
	var conf = confirm('are you sure delete this data ?');
	if(conf == true){
		window.location = "{{ asset('category/delete') }}/"+ id;
	}
	return false;
}

//DOM ready
$(document).ready(function () {
    $('#table-category').DataTable();

    //get id update
    //event listener javascript
    $('.update-category').on('click', function(){
        var id = $(this).attr('data-id');
        console.log(id);
        //dapat data product by id
        $.ajax({
			url : "{{ asset('/category/get') }}/" + id,
			success: function(data){
				console.log(data);
				$('[name="category_id_update"]').val(data.id);
				$('[name="category_name_update"]').val(data.category_name);
			},
			dataType: 'JSON'
        });
    	$('#update-modal').modal();	
    });
});
</script>
@endsection
