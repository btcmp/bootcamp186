@extends('layouts.app')
<!-- @section('header')
	@parent
	header 2
@endsection -->
@section('content')
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
@endsection