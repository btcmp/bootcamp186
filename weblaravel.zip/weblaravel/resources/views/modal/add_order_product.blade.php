<div id="add-order-product" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="search-barang" class="form-group">
        	<input type="text" class="form-control" id="search" /><br/>
        	<a class="btn btn-sm btn-primary" href="#">Search</a>
        </div>
        <div id="data-temporary" style="height: 300px;">
        	<table id="table-temporary" class="table">
				<thead>
					<tr>
						<th>Nama Produk</th>
						<th>price</th>
						<th>Jumlah</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
        	</table>
        </div>
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-primary" value="Tambahkan" />
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
