<div id="update-modal" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Variant</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(asset('/variant/update')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="variant_id_update" />
			<div class="form-group">
				<input type=text class="form-control" name="variant_name_update"
					placeholder="Product Name">
			</div>
			<div class="form-group">
				<select class="form-control" name="category_id_update">
					<option value="0">-- Select Category --</option>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($cat->id); ?>" ><?php echo e($cat->category_name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-primary" value="Save change" />
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
