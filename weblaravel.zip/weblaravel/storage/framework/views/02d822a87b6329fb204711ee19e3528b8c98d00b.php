<?php $__env->startSection('loadcss'); ?>
	##parent-placeholder-63f86990b205d9c3b2b7992a4e094db9a8f72fe0##
	<link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('master-active', 'active'); ?>
<?php $__env->startSection('pembelian-active', 'active'); ?>
<?php $__env->startSection('title', 'Pembelian Product'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('status')): ?>
       <div class="alert alert-success" ><?php echo session('status'); ?></div>
<?php endif; ?>

<div class="box box-info">
	<div class="box-header">
		<i class="fa fa-envelope"></i>

		<h3 class="box-title">Pembelian</h3>
		<!-- tools box -->
		<div class="pull-right box-tools">
			<button type="button" class="btn btn-info btn-sm"
				data-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
		<!-- /. tools -->
	</div>
	<div class="box-body">
		<form action="<?php echo e(asset('/pembelian/save')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<input type=text class="form-control" name="no_faktur" value="<?php echo e($no_faktur); ?>"
					placeholder="No Fakture">
			</div>
			<div class="form-group">
				<input type=number class="form-control" name="total_item"
					placeholder="Total Item">
			</div>
			<div class="form-group">
				<input type=number class="form-control" name="total_bayar"
					placeholder="Total Bayar">
			</div>
			<!-- <div class="box-footer clearfix">
				<input type="submit" name="submit" value="save" class="pull-right btn btn-primary" />
        	</div> -->
		</form>
	</div>
	
</div>
<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Detail Pembelian</h3>
		<div class="box-tools pull-right">
			<button type="button" class="btn btn-box-tool" data-widget="collapse">
				<i class="fa fa-minus"></i>
			</button>
			<button type="button" class="btn btn-box-tool" data-widget="remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
	</div>
	<!-- /.box-header -->
	<div class="box-body">
		<div class="table-responsive">
			<table id=table-category class="table table-bordered table-hover" style="width: 100%">
				<thead>
					<tr>
						<th>Nama Barang</th>
						<th>Jumlah barang</th>
						<th>Harga Barang</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody> 
				</tbody>
			</table>
		</div>
		<!-- /.table-responsive -->
	</div>
	<!-- /.box-body -->
	<div class="box-footer clearfix">
		<a href="javascript:void(0)"
			class="btn btn-sm btn-info btn-flat pull-left">Order barang</a> 
		<a id="add-barang" href="javascript:void(0)"
			class="btn btn-sm btn-default btn-flat pull-right">Tambah Barang</a>
	</div>
	<!-- /.box-footer -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loadjs'); ?>
	##parent-placeholder-d9f02b263cc7f73cd21fff0a9b9a706fcc1ac273##
	<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/demo.js"></script>
<script>
//DOM ready
$(document).ready(function () {
   $('#add-barang').on('click', function(){
		$('#add-order-product').modal();
	});

	$('#search').on('keyup', function(){
		var dataSearch = $(this).val();
		console.log(dataSearch);
		$.ajax({
			url : '<?php echo e(asset("/product/search")); ?>/'+dataSearch,
			success: function(data){
				console.log(data);
				addTemporaryTable(data);
			},
			dataType: 'JSON'
		});
	});

	function addTemporaryTable(data){
		var table = $("#table-temporary > tbody");
		$('.add-tr-product').remove();
		$.each(data, function(i, v){
			var element = "<tr class='add-tr-product'>";
				element += "<td>";
					element += v.name;
				element += "</td>";
				element += "<td>";
					element += v.price;
				element += "</td>";
				element += "<td>";
					element += "<input type='number' style='10px;' value='1'>";
				element += "</td>";
			element +="</tr>";
			table.append(element);
		});
	}
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modal.add_order_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.mylayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>