<!-- <?php $__env->startSection('header'); ?>
	##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	header 2
<?php $__env->stopSection(); ?> -->
<?php $__env->startSection('content'); ?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
hai, <?php echo $name; ?>
home page untuk home controller
<?php 
  echo "<pre>";
      print_r($salary);
  echo "</pre>";
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>