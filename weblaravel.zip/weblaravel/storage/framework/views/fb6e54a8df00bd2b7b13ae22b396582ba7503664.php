<?php $__env->startSection('loadcss'); ?>
	##parent-placeholder-63f86990b205d9c3b2b7992a4e094db9a8f72fe0##
	<link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../assets/AdminLTE-2.4.5/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('master-active', 'active'); ?>
<?php $__env->startSection('product-active', 'active'); ?>
<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('status')): ?>
       <div class="alert alert-success" ><?php echo session('status'); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="box box-info">
	<div class="box-header">
		<i class="fa fa-envelope"></i>

		<h3 class="box-title">Product Entry</h3>
		<!-- tools box -->
		<div class="pull-right box-tools">
			<button type="button" class="btn btn-info btn-sm"
				data-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
		<!-- /. tools -->
	</div>
	<div class="box-body">
		<form action="<?php echo e(asset('/product/save')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<input type=text class="form-control" name="name"
					placeholder="Product Name">
						<small class="text-danger">
                      		<?php echo e($errors->first('name')); ?>

                       	</small>
			</div>
			<div class="form-group">
				<input type="number" class="form-control" name="price"
					placeholder="Product Price">
					<small class="text-danger">
                      		<?php echo e($errors->first('price')); ?>

                       	</small>
			</div>
			<div class="form-group">
				<input type="number" class="form-control" name="stock"
					placeholder="Stock">
			</div>
			<div class="form-group">
				<select class="form-control" name="category_id">
					<option value="0">-- Select Category --</option>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($cat->id); ?>" ><?php echo e($cat->category_name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<select class="form-control" name="variant_id">
					<option value="0">-- Select Variant --</option>
				</select>
			</div>
			<div class="box-footer clearfix">
				<input type="submit" name="submit" value="save" class="pull-right btn btn-primary" />
        	</div>
		</form>
	</div>
	
</div>
<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Master Product</h3>
		<div class="box-tools pull-right">
			<button type="button" class="btn btn-box-tool" data-widget="collapse">
				<i class="fa fa-minus"></i>
			</button>
			<button type="button" class="btn btn-box-tool" data-widget="remove">
				<i class="fa fa-times"></i>
			</button>
		</div>
	</div>
	<!-- /.box-header -->
	<div class="box-body">
		<div class="table-responsive">
			<table id=table-product class="table table-bordered table-hover" style="width: 100%">
				<thead>
					<tr>
						<th>name</th>
						<th>price</th>
						<th>stock</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($product->name); ?></td>
						<td><?php echo e($product->price); ?></td>
						<td><?php echo e($product->stock); ?></td>
						<td>
							<a href='#' onclick="confirmDelete('<?php echo e($product->id); ?>')" class='btn btn-danger btn-sm'>Delete</a> 
							<a href='#' data-id = "<?php echo e($product->id); ?>" class='update-product btn btn-warning btn-sm'>Update</a> 
							<a href='#' data-id = "<?php echo e($product->id); ?>" class='view-product btn btn-info btn-sm'>View</a> 
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.table-responsive -->
	</div>
	<!-- /.box-body -->
	<div class="box-footer clearfix">
		<a href="javascript:void(0)"
			class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a> <a
			href="javascript:void(0)"
			class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
	</div>
	<!-- /.box-footer -->
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('loadjs'); ?>
	##parent-placeholder-d9f02b263cc7f73cd21fff0a9b9a706fcc1ac273##
	<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../../assets/AdminLTE-2.4.5/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../assets/AdminLTE-2.4.5/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../assets/AdminLTE-2.4.5/dist/js/demo.js"></script>
<script>
//javascript

function confirmDelete(id){
	var conf = confirm('are you sure delete this data ?');
	if(conf == true){
		window.location = "<?php echo e(asset('product/delete')); ?>/"+ id;
	}
	return false;
}

//DOM ready
$(document).ready(function () {
    $('#table-product').DataTable();
    //get id update
    //event listener javascript
    $('.update-product').on('click', function(){
        var id = $(this).attr('data-id');
        //dapat data product by id
        $.ajax({
			url : "<?php echo e(asset('/product/get')); ?>/" + id,
			success: function(data){
				console.log(data);
				$('[name="id_update"]').val(data.id);
				$('[name="name_update"]').val(data.name);
				$('[name="price_update"]').val(data.price);
				$('[name="stock_update"]').val(data.stock);
				$('[name="category_id_update"]').val(data.category_id);
			},
			dataType: 'JSON'
        });
    	$('#update-modal').modal();	
    });

    //view detail
    $('.view-product').on('click', function(){
    	var id = $(this).attr('data-id');
        //dapat data product by id
        $.ajax({
			url : "<?php echo e(asset('/product/get')); ?>/" + id,
			success: function(data){
				console.log(data);
				$('[name="name_view"]').val(data.name);
				$('[name="price_view"]').val(data.price);
				$('[name="stock_view"]').val(data.stock);
				$('[name="category_view"]').val(data.category_name);
			},
			dataType: 'JSON'
        });
		$('#view_detail_product').modal();
    });

    //select on category
    $('[name="category_id"]').on('change', function(){
		var id = $(this).val();
		$.ajax({
			url : '<?php echo e(asset("/variant/getvariantbycategory/")); ?>/'+id,
			dataType:'JSON',
			success: function(data){
				fillOption(data);
			}
		});
    });

    function fillOption(data){
    	$('.add-option').remove();
    	console.log(data);
		$.each(data, function(i, value){
		var option = "<option class='add-option' value='"+value.variant_id+"' >";
				option += value.variant_name;
			option += "</option>";
			//console.log(i, value);
			$('[name="variant_id"]').append(option);
		});
     }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modal.view_detail_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.update_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.mylayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>