<?php $__env->startSection('master-active', 'active'); ?>
<?php $__env->startSection('product-active', 'active'); ?>
<?php echo $__env->make('layouts.mylayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>